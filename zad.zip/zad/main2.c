#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <wait.h>
#include <ctype.h>

#define MAX_NUM 10

typedef struct command{
    char *command;
    char **arguments;
} command_t;

typedef struct commandLine{
    char *commandName;
    command_t **commandsSequence;
    int numberOfCommands;
} commandLine_t;

typedef struct execLine{
    command_t **commandsSequence;
    int numberOfCommands;
} execLine_t;

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)  // All spaces?
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

command_t *parseCommand(char *line){
    printf("line 47  %s %d\n", line);
    command_t *newCommand = (command_t*)calloc(1, sizeof(command_t));

    char *command = strtok(line, " ");
    char **arguments = (char**)calloc(MAX_NUM, sizeof(char*));

    newCommand->command = command;

    int i  = 0;
    arguments[i] = command;
    i++;
    while(i < MAX_NUM && (command = strtok(NULL, " ")) != NULL){
        arguments[i] = command;
        i++;
    }
    arguments[i] = NULL;

    newCommand->arguments = arguments;
    return newCommand;
}

commandLine_t *parseCommandLine(char *line){
    printf("line 68  %s %d\n", line);
    commandLine_t *newCommandLine = (commandLine_t*)calloc(1, sizeof(commandLine_t));

    newCommandLine->commandName = strtok(line, "=");
    char *command;
    command_t **commandsSequence = (command_t**)calloc(MAX_NUM, sizeof(command_t*));
    int numberOfCommands = 0;

    while(numberOfCommands < MAX_NUM && (command = strtok(NULL, "|")) != NULL){
        printf("line 76  %s %d\n", command);
        commandsSequence[numberOfCommands] = parseCommand(command);
        numberOfCommands++;
    }

    newCommandLine->commandsSequence = commandsSequence;
    newCommandLine->numberOfCommands = numberOfCommands;

    return newCommandLine;
}

execLine_t *parseExecLine(char *line, commandLine_t **commandLines, int numberOfCommandLines){
    execLine_t *newExecLine = (execLine_t*)calloc(1, sizeof(execLine_t));
    command_t **commandsSequence = (command_t**)calloc(MAX_NUM * MAX_NUM, sizeof(command_t*));
    char *command = strtok(line, "|");
    int numberOfCommands = 0;
    for(int i = 0; i < numberOfCommandLines; i++){
        if(strstr(commandLines[i]->commandName, trimwhitespace(command))){
            printf("line 93  %s %d\n", command, i);
            for(int j = 0; j < commandLines[i]->numberOfCommands; j++){
                printf("line 95  %s %d\n", commandLines[i]->commandsSequence[j]->command, i);
                commandsSequence[numberOfCommands] = commandLines[i]->commandsSequence[j];
                numberOfCommands++;
            }
        }
    }
    while(numberOfCommands < MAX_NUM * MAX_NUM && (command = strtok(NULL, "|")) != NULL){
        for(int i = 0; i < numberOfCommandLines; i++){
            if(strstr(commandLines[i]->commandName, trimwhitespace(command))){
                printf("line 104  %s\n", command);
                for(int j = 0; j < commandLines[i]->numberOfCommands; j++){
                    printf("line 106  %s %d\n", commandLines[i]->commandsSequence[j]->command, i);
                    commandsSequence[numberOfCommands] = commandLines[i]->commandsSequence[j];
                    numberOfCommands++;
                }
            }
        }
    }

    commandsSequence[numberOfCommands] = NULL;

    newExecLine->commandsSequence = commandsSequence;
    newExecLine->numberOfCommands = numberOfCommands;
    return newExecLine;
}
int main(int argc, char **argv){
    if (argc != 2) {
        printf("Wrong number of arguments!\n");
        return -1;
    }

    FILE *commandsFile = fopen(argv[1], "r");

    if (!commandsFile) {
        printf("Error while opening file!\n");
        return -1;
    }

    char *line = NULL;
    size_t lineSize = 0;
    int read;

    int commandLinesCounter = 0;
    int execLinesCounter = 0;

    while((read = getline(&line, &lineSize, commandsFile)) != -1){
        if (strstr(line, "=")) {
            commandLinesCounter = commandLinesCounter + 1;
        }
        else {
            execLinesCounter = execLinesCounter + 1;
        }
    }

    rewind(commandsFile);

    commandLine_t **commandLines  = (commandLine_t**)calloc(commandLinesCounter, sizeof(commandLine_t*));
    execLine_t **execLines = (execLine_t**)calloc(execLinesCounter, sizeof(execLine_t*));

    commandLinesCounter = 0;
    execLinesCounter = 0;

    while((read = getline(&line, &lineSize, commandsFile)) != -1){
        if (strstr(line, "=")) {
            commandLines[commandLinesCounter] = parseCommandLine(line);
            line = NULL;
            lineSize = 0;  
            commandLinesCounter++;
        }
        else {
            printf("line 165  %s\n", line);
            execLines[execLinesCounter] = parseExecLine(line, commandLines, commandLinesCounter);
            line = NULL;
            lineSize = 0; 
            execLinesCounter++;
        }
    }

    for(int i = 0; i < execLinesCounter; i++){
        printf("%d\n", execLines[i]->numberOfCommands);
        int **pipeTMP = (int**)calloc(execLines[i]->numberOfCommands, sizeof(int*));
        for(int j = 0; j < execLines[i]->numberOfCommands ; j++) {
            pipeTMP[j] = (int*)calloc(2, sizeof(int));
            
            if (pipe(pipeTMP[j]) == -1) {
                printf("Error while creating pipe!\n");
                return -1;
            }
        }
    
        for(int j = 0; j < execLines[i]->numberOfCommands; j++){
            if (fork() == 0) {
                if( j > 0) {
                    dup2(pipeTMP[j - 1][0], STDIN_FILENO);
                }
                if(j < execLines[i]->numberOfCommands - 1) {
                    dup2(pipeTMP[j][1], STDOUT_FILENO);
                }
                for(int k = 0; k < execLines[i]->numberOfCommands; k++) {
                    close(pipeTMP[k][1]);
                    close(pipeTMP[k][0]);
                }
                printf("%s \n", execLines[i]->commandsSequence[j]->command);
                if(execvp(execLines[i]->commandsSequence[j]->command, execLines[i]->commandsSequence[j]->arguments) == -1){
                    printf("Error while executing command line!\n");
                    return -1;
                }
                else{
                    printf("OK!");
                }
            }
        }

        for(int j = 0; j < execLines[i]->numberOfCommands; j++) {
            close(pipeTMP[j][1]);
            close(pipeTMP[j][0]);
        }
        for (int j = 0; j < execLines[i]->numberOfCommands; j++)
            wait(NULL);
        }

    fclose(commandsFile);
    return 0;
}