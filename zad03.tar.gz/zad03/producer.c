#define _POSIX_C_SOURCE 200809L
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/file.h>


int main(int argc, char **argv) {
    srand(getpid());

    if(argc != 5) {
        printf("Wrong number of arguments!\n");
        return -1;
    }

    FILE *pipe = fopen(argv[1], "w");
    if(!pipe) {
        printf("Error while opening pipe!\n");
        return -1;
    }

    int row = atoi(argv[2]);

    FILE *file = fopen(argv[3], "r");
    if(!file) {
        printf("Error while opening file!\n");
        return -1;
    }

    int n = atoi(argv[4]);    
    char *buff = (char*)calloc(n, sizeof(char));

    while(fread(buff, sizeof(char), n, file) > 0) {
        sleep(rand() % 2 + 1);
        flock(fileno(pipe), LOCK_EX);
        fwrite(&row, sizeof(int), 1, pipe);
        fwrite(buff, sizeof (char), n, pipe);
        flock(fileno(pipe), LOCK_UN);
    }

    fclose(file);
    fclose(pipe);

    return 0;
}