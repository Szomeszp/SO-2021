#define _GNU_SOURCE
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <errno.h>
#include <sys/file.h>

const int BUFF_FILL = 1024;


int main(int argc, char **argv) {
    if(argc != 4) {
        printf("Wrong number of arguments!\n");
        return -1;
    }

    FILE *pipe = fopen(argv[1], "r");
    if(!pipe) {
        printf("Error while opening pipe!\n");
        return -1;
    }
    
    int n =  strtol(argv[3], NULL, 10);

    char *buff = malloc(sizeof (char) * (n + 1));
    int line;
    while(fread(&line, sizeof(int), 1, pipe)) {
        FILE *file = fopen(argv[2], "rw+");
        if(!file) {
            printf("CONSUMER - Error while opening file!\n");
            return -1;
        }

        fread(buff, sizeof(char), n, pipe);
        flock(fileno(file), LOCK_EX);

        int lineNumber = 0;
        char c;
        fseek(file, 0, SEEK_SET);
        while(fread(&c, sizeof (char), 1, file)) {
            if (c == '\n'){
                lineNumber++;
            }
            
            if (lineNumber >= line) {
                fseek(file, -1, SEEK_CUR);
                char buff[4096];
                int readed = fread(buff, sizeof(char), 4096, file);
                fseek(file, -readed, SEEK_CUR);
                fwrite(buff, sizeof(char), n, file);
                fwrite(buff, sizeof(char), readed, file);
                break;
            }

        }
        if(lineNumber < line) {
            for(int i = lineNumber + 1; i <= line; i++) {
                char str[5];
                sprintf(str, "%d \n", i);
                fwrite(str, sizeof (char ), strlen(str), file);
            }
            fseek(file, -1, SEEK_CUR);
            fwrite(buff, sizeof(char), n, file);
            fwrite("\n", sizeof(char), 1, file);
        }

        flock(fileno(file), LOCK_UN);
        fclose(file);
    }


    fclose(pipe);

    return 0;
}