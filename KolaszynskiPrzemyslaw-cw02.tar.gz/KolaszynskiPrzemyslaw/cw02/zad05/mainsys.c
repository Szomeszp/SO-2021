#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <sys/times.h>
#include <unistd.h>
#include <fcntl.h>


int main(int argc, char **argv){
    struct tms start;
    struct tms end;

    times(&start);


    if(argc >= 4){
        printf("Too many arguments!\n");
        return -1;
    }

    int fileRead = -1;
    int fileWrite = -1;

    if(argc == 1){
        printf("No arguments given!\n");
        printf("You have to specify paths to files!\n");
        return -1;
    }
    else if(argc == 2){
        printf("Path to saving file was not specified!\n");
        return -1;
    }
    else{
        fileRead = open(argv[1], O_RDONLY);
        fileWrite = open(argv[2], O_WRONLY|O_CREAT, S_IRUSR | S_IWUSR);
    }

    if(fileRead == -1 || fileWrite == -1){
        printf("Error while opening files!\n");
        if(fileRead){
            close(fileRead);
        }
        if(fileWrite){
            close(fileWrite);
        }
        return -1;
    }

    char buf;
    int count;

    while (1){
        count = 0;

        while (read(fileRead, &buf, sizeof(char)) == 1){
            if(count == 0 && buf == '\n'){
                count = count + 1;
                break;
            }
            write(fileWrite, &buf, sizeof(char));
            count = count + 1;
            if(count == 50){
                if(buf != '\n'){
                    write(fileWrite, "\n", sizeof(char));
                }
                break;
            }
            if(buf == '\n'){
                break;
            }
        }

        if (!count){
            break;
        }
    }

    close(fileRead);
    close(fileWrite);

    times(&end);
    printf("TIME: %f\n", (double)(end.tms_stime - start.tms_stime)/sysconf(_SC_CLK_TCK));

    return 0;
}